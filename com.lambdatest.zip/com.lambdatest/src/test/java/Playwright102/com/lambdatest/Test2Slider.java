package Playwright102.com.lambdatest;	

	import com.microsoft.playwright.*;
	import org.junit.jupiter.api.*;

	import static org.junit.jupiter.api.Assertions.*;

	public class Test2Slider extends LambdaTestBase{
	    static Playwright playwright;
	    static Browser browser;

	    @BeforeAll
	    static void setup() {
	        playwright = Playwright.create();
	        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
	    }

	    @AfterAll
	    static void tearDown() {
	        browser.close();
	        playwright.close();
	    }

	    @Test
	    void testSliderTo95() {
	        BrowserContext context = browser.newContext();
	        Page page = context.newPage();
	        page.navigate("https://www.lambdatest.com/selenium-playground");

	        page.click("text=Drag & Drop Sliders");

	        Locator slider = page.locator("input[type='range']").first();
	        slider.evaluate("s => s.value = 95");
	       
	        page.dispatchEvent("input[type=range]", "input");

	        String value = page.textContent("#rangeSuccess");
	        page.setDefaultTimeout(10000); 
	        
	        assertEquals("15", value);
	    }
	}

	
	
	
	

