package Playwright102.com.lambdatest;

//src/test/java/com/lambdatest/LambdaTestBase.java


import com.microsoft.playwright.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class LambdaTestBase {
 protected Playwright playwright;
 protected Browser browser;
 protected BrowserContext context;
 protected Page page;

 protected void start(String testName) {
     playwright = Playwright.create();
     try {
         Map<String, Object> ltOptions = new HashMap<>();
         ltOptions.put("platform", "Windows 10");
         ltOptions.put("build", "Playwright-Java-Build");
         ltOptions.put("name", testName);
         ltOptions.put("user", "nagpureanuprita");
         ltOptions.put("accessKey", "6DRHTie2mC1lF9tVy01L2hQfTXyOSdmPd4QYS820prUKSFkXkh");
         ltOptions.put("network", true);
         ltOptions.put("console", true);
         ltOptions.put("video", true);
         ltOptions.put("visual", true);

         Map<String, Object> capabilities = new HashMap<>();
         capabilities.put("browserName", "Chrome");
         capabilities.put("browserVersion", "latest");
         capabilities.put("LT:Options", ltOptions);

         String wsEndpoint = "wss://cdp.lambdatest.com/playwright?capabilities=" +
                 URLEncoder.encode(new Object().toString(), StandardCharsets.UTF_8);

         browser = playwright.chromium().connect(wsEndpoint);
         context = browser.newContext();
         page = context.newPage();
     } catch (Exception e) {
         e.printStackTrace();
     }
 }

 protected void stop() {
     if (browser != null) browser.close();
     if (playwright != null) playwright.close();
 }
}
