package Playwright102.com.lambdatest;
import com.google.gson.JsonObject;
import com.microsoft.playwright.*;

import org.junit.jupiter.api.*;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import static org.junit.jupiter.api.Assertions.*;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;




public class TestSimpleForm extends LambdaTestBase {

	
	static Playwright playwright;
	static Browser browser;
	

	    @BeforeAll	   
	    static void setup() {
	        playwright = Playwright.create();
	        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
	        
	    } 
	    

	    @AfterAll
	    static void tearDown() {
	        browser.close();
	        playwright.close();
	    }

	    @Test
	    void testSimpleFormDemo() {
	        BrowserContext context = browser.newContext();
	        Page page = context.newPage();
	        page.navigate("https://www.lambdatest.com/selenium-playground");

	        page.click("text=Simple Form Demo");
	        assertTrue(page.url().contains("simple-form-demo"));

	      //  String message = "Welcome to LambdaTest";
	        
	        page.fill("//input[@id='user-message']", "Welcome to LambdaTest");
	        page.setDefaultTimeout(30000);
	        page.click("//*[@id=\"showInput\"]");

	        String output = page.textContent("#message");
	        assertEquals("Welcome to LambdaTest", output);

	    }
	
}


	    
	    
	    
	    
	    
	    
	    
	    
	    