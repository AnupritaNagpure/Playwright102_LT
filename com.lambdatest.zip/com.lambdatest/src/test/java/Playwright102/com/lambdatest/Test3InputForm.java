package Playwright102.com.lambdatest;


import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class Test3InputForm extends LambdaTestBase{
    static Playwright playwright;
    static Browser browser;

    @BeforeAll
    static void setup() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
    }

    @AfterAll
    static void tearDown() {
        browser.close();
        playwright.close();
    }

    @Test
    void testInputFormSubmit() {
        BrowserContext context = browser.newContext();
        Page page = context.newPage();
        page.navigate("https://www.lambdatest.com/selenium-playground");
        page.setDefaultTimeout(10000); 
        page.click("text=Input Form Submit");

        page.click("button:has-text('Submit')");
        assertTrue(page.isVisible("input[name=name]:invalid"));

        page.fill("input[name=name]", "John Doe");
        page.fill("input[id=inputEmail4]", "john@example.com");
        page.fill("input[id=inputPassword4]", "Pass123");
        page.fill("input[name=company]", "LambdaTest");
        page.fill("input[name=website]", "https://lambdatest.com");
        page.selectOption("select[name=country]", "United States");
        page.fill("input[name=city]", "NY");
        page.fill("input[name=address_line1]", "123 Street");
        page.fill("input[id=inputAddress2]", "Sector 44A");
        page.fill("input[id=inputState]", "NY");
        page.fill("input[id=inputZip]", "10001");

        page.click("button:has-text('Submit')");
        page.evaluate("window.scrollTo(0, 0);");
        assertTrue(page.textContent(".success-msg.hidden").contains("Thanks for contacting us, we will get back to you shortly."));
    }
}
